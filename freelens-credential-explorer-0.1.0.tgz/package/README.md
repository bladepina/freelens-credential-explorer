# Freelens Credential Explorer Extension

A Freelens extension (PoC) to quickly visualize the status of Kubernetes credentials with the relationship:

Secret → Deployment → Pods → ServiceAccount

## Overview

Provide an operational dashboard to answer these questions in seconds:

- How old is a Secret?
- When does it expire?
- In which namespace does it live?
- Where does it come from (Vault, External Secrets, manual)?
- Are there critical warnings?

## Current Status

This scaffold includes:

- Freelens extension structure (`main` + `renderer`)
- `Credential Explorer` page in the cluster menu
- Initial table with columns: Secret, age, expiry, namespace, origin, relationship, warning
- Filters by namespace, origin, and severity
- Sorting by severity, expiry, age, namespace, and secret
- Normalized severity (`none`, `info`, `warning`, `critical`) with badges
- Mock dataset for developing UI and logic without cluster dependency

## Screenshot

![Credential Explorer UI](docs/credential-explorer.png)

## Project Structure

- `src/main/index.ts`: main extension entrypoint
- `src/renderer/index.tsx`: page registration and menu
- `src/renderer/CredentialExplorerPage.tsx`: initial UI
- `src/renderer/credential-store.ts`: mock adapter + indicator calculations
- `src/common/types.ts`: shared models

## Local Build

Prerequisites:

- Node.js 24+
- pnpm

Commands:

```sh
pnpm install
pnpm build
pnpm pack
```

The generated tarball can be loaded in Freelens from Extensions.
